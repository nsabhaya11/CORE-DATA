//
//  ViewController.swift
//  coredata
//
//  Created by MACOS on 11/25/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit
import cored
class ViewController: UIViewController {

    @IBOutlet weak var txtempid: UITextField!
    
    @IBOutlet weak var txtempname: UITextField!
    
    
    @IBOutlet weak var txtempadd: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        
    
        
        
    }
    
    
    @IBAction func btninsert(_ sender: AnyObject) {
    }
    

    @IBAction func btnupdate(_ sender: AnyObject) {
    }
    
    @IBAction func btndelete(_ sender: AnyObject) {
    }
    
    
    @IBAction func btnselect(_ sender: AnyObject) {
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

